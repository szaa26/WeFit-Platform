<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{
    public function index()
    {
        $data    = Category::get()->all();
        return view('category.index', compact('data'));
    }

    public function create()
    {
        return view('category.create');
    }

    public function store(Request $request)
    {
        $data = new Category;
        $data->category_name = $request->name;

        if ($request->hasFile('image')) {
            $file            = $request->file('image');
            $extension       = $file->getClientOriginalExtension();
            $fileNameToStore = 'banner-'.time().'.'.$extension;
            $path            = public_path('banner');
            $file->move($path, $fileNameToStore);

            $data->banner_image = $fileNameToStore;
        }
        $data->save();

        return redirect('/category')->with('success','Add data success.!');
    }

    public function show($id)
    {
        $data = Category::find($id);
        return view('category.edit',compact('data'));
    }

    public function update(Request $request, $id)
    {
        $data = Category::find($id);
        $data->category_name = $request->name;
        if ($request->hasFile('image')) {
            $file            = $request->file('image');
            $extension       = $file->getClientOriginalExtension();
            $fileNameToStore = 'banner-'.time().'.'.$extension;
            $path            = public_path('banner');
            $file->move($path, $fileNameToStore);

            $data->banner_image = $fileNameToStore;
        }

        $data->save();

        return redirect('/category')->with('success','Update data success.!');
    }

    public function destroy($id)
    {
        Category::find($id)->delete();
        return redirect('/category')->with('success','Delete data success.!');
    }
}
