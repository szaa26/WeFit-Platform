<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Province;

class LoginController extends Controller
{
    public function index()
    {
    	return view('auth.login');
    }

    public function doLogin(Request $request)
    {
        $checkUser = User::where('email', $request->email)
            ->get()->first();
        if (!empty($checkUser)) {
            if (Hash::check($request->password, $checkUser->password)) {
                $request->session()->put('auth_user', $checkUser);
                return redirect('/');
            }else{
                return redirect()->back()->with('error', 'Password yang anda masukan salah.!');
            }
        }else{
            return redirect()->back()->with('error', 'Email tidak terdaftar.!');
        }
    }

    public function logout(Request $request)
    {
        $request->session()->forget('auth_user');
        return redirect('/');
    }

    public function register()
    {
        $province = Province::orderBy('name', 'ASC')->get()->all();
        return view('auth.register', compact('province'));
    }

    public function doRegister(Request $request)
    {
        $checkUser = User::where('email', $request->email)
            ->first();

        if (!empty($checkUser)) {
            return redirect()->back()->with('error', 'Email already exists.!');
        }

        $data = new User;
        $data->name        = $request->name;
        $data->email       = $request->email;
        $data->phone       = $request->phone;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->password    = Hash::make($request->password);
        $data->roles       = 'venue';
        $data->save();

        return redirect('/login')->with('success','Register success.!');
    }
}