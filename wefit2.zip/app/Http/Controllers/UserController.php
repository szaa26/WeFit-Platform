<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        $data = User::where('roles', 'admin')->get()->all();
        return view('user.index', compact('data'));
    }

    public function create()
    {
        return view('user.create');
    }

    public function store(Request $request)
    {
        $checkUser = User::where('email', $request->email)
            ->first();

        if (!empty($checkUser)) {
            return redirect()->back()->with('error', 'Email already exists.!');
        }

        $user = new User;
        $user->name     = $request->name;
        $user->email    = $request->email;
        $user->password = Hash::make($request->password);
        $user->roles    = 'admin';
        $user->save();

        return redirect('/users')->with('success','Add data success.!');
    }

    public function show($id)
    {
        $data = User::find($id);
        return view('user.edit',compact('data'));
    }

    public function update(Request $request, $id)
    {

        $checkUser = User::where('email', $request->email)
            ->where('id', '!=', $id)
            ->first();

        if (!empty($checkUser)) {
            return redirect('/users')->with('error', 'Email already exists.!');
        }

        $user = User::find($id);
        $user->name     = $request->name;
        $user->email    = $request->email;
        $user->password = $request->password != '' ? Hash::make($request->password) : $user->password;
        $user->save();

        return redirect('/users')->with('success','Update data success.!');
    }

    public function destroy($id)
    {
        User::find($id)->delete();
        return redirect('/users')->with('success','Delete data success.!');
    }
}
