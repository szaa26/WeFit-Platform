<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Venue;
use App\Models\Booking;

class ReportController extends Controller
{
    public function report_venue(Request $request)
    {
        $session_user = $request->session()->get('auth_user');
        
        if ($session_user->roles == 'admin') {
            $venue = Venue::orderBy('venue_name', 'ASC')->get()->all();
        }else{
            $venue = Venue::orderBy('venue_name', 'ASC')->where('user_id', $session_user->id)->get()->all();
        }


        $start_date     = ($request->start != null)?$request->start:'';
        $end_date       = ($request->end != null)?$request->end:'';
        $selected_venue = ($request->venue != null)?$request->venue:'';

        $data = [];

        if ($start_date != "") {
            $get_data = Booking::with(['venue'])->where('created_at', '>=', $start_date)->where('created_at', '<=', $end_date);
            $get_data = $get_data->where('status', 1); // -> Get only paid booking order

            if ($session_user->roles != 'admin') {
                $venue_id    = [];
                foreach ($venue as $key => $vnval) {
                    $venue_id[] = $vnval->id;
                }
                if(!empty($venue_id)){
                    $get_data = $get_data->whereIn('venue_id', $venue_id);
                }
            }

            if ($selected_venue != "") {
                $get_data = $get_data->where('venue_id', $selected_venue);
            }
            $get_data = $get_data->get()->all();
            $data     = $get_data;
        }
        // debugCode($get_data);

        return view('report.report_venue', compact('venue', 'start_date', 'end_date', 'selected_venue', 'data'));
    }
}
