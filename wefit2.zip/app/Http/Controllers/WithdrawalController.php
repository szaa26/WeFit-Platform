<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\Withdrawal;

class WithdrawalController extends Controller
{
    public function index(Request $request)
    {
        $session_user = $request->session()->get('auth_user');

        $data = Withdrawal::where('user_id', $session_user['id'])
            ->orderBy('id', 'DESC')
            ->get()->all();

        return view('withdrawal.index', compact('data'));
    }

    public function doWithdrawal(Request $request)
    {
        $session_user = $request->session()->get('auth_user');
        $user_id      = $session_user['id'];

        $data = Booking::join('venue', 'venue.id', '=', 'booking.venue_id')->where('venue.user_id', $user_id)
            ->select('booking.*')
            ->where('status', 1)
            ->where('withdrawal_status', 0)->get()->all();

        if (empty($data)) {
            return redirect()->back()->with('error', 'There is nothing to withdraw.!');
        }

        $total = 0;

        foreach ($data as $key => $value) {
            $b = Booking::find($value->id);
            $b->withdrawal_status = 1;
            $b->save();

            $total+= $value->total_payment;
        }

        $wd = new Withdrawal;
        $wd->user_id        = $user_id;
        $wd->bank_name      = $request->bank_name;
        $wd->account_number = $request->account_number;
        $wd->account_name   = $request->account_name;
        $wd->total          = $total;
        $wd->status         = 0;
        $wd->save();

        return redirect()->back()->with('success', 'Withdrawal request has been created.!');
    }

    public function withdrawalRequest(Request $request)
    {
        $data = Withdrawal::orderBy('id', 'DESC')
            ->get()->all();

        return view('withdrawal.index_request', compact('data'));
    }

    public function completeWithdrawal(Request $request, $id)
    {
        $data = Withdrawal::find($id);
        $data->status = 1;
        $data->save();

        return redirect()->back()->with('success', 'Withdrawal request has been completed.!');
    }
}
