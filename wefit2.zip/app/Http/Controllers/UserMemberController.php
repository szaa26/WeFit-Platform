<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserMember;
use App\Models\Province;
use App\Models\Regency;
use Illuminate\Support\Facades\Hash;

class UserMemberController extends Controller
{
    public function index()
    {
        $data    = UserMember::with(['regency', 'province'])->get()->all();
        return view('user_member.index', compact('data'));
    }

    public function create()
    {
        $province = Province::orderBy('name', 'ASC')->get()->all();
        // debugCode($province);
        return view('user_member.create', compact('province'));
    }

    public function store(Request $request)
    {
        $checkUser = UserMember::where('email', $request->email)
            ->first();

        if (!empty($checkUser)) {
            return redirect()->back()->with('error', 'Email already exists.!');
        }

        $data              = new UserMember;
        $data->name        = $request->name;
        $data->email       = $request->email;
        $data->phone       = $request->phone;
        $data->address     = $request->address;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->password    = Hash::make($request->password);
        $data->save();

        return redirect('/users-member')->with('success','Add data success.!');
    }

    public function show($id)
    {
        $data     = UserMember::find($id);
        $province = Province::orderBy('name', 'ASC')->get()->all();
        $city     = Regency::where('province_id', $data->province_id)
            ->orderBy('name', 'ASC')
            ->get()->all();
        return view('user_member.edit',compact('data', 'province', 'city'));
    }

    public function update(Request $request, $id)
    {

        $checkUser = UserMember::where('email', $request->email)
            ->where('id', '!=', $id)
            ->first();

        if (!empty($checkUser)) {
            return redirect('/users-member')->with('error', 'Email already exists.!');
        }

        $data = UserMember::find($id);
        $data->name        = $request->name;
        $data->email       = $request->email;
        $data->phone       = $request->phone;
        $data->address     = $request->address;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->password    = $request->password != '' ? Hash::make($request->password) : $data->password;
        $data->save();

        return redirect('/users-member')->with('success','Update data success.!');
    }

    public function destroy($id)
    {
        UserMember::find($id)->delete();
        return redirect('/users-member')->with('success','Delete data success.!');
    }
}
