<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BookingTimeDetail extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'booking_time_detail';

    public function time_data()
    {
        return $this->belongsTo(TimeData::class)->withTrashed();
    }
}
