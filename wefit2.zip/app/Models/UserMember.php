<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserMember extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'user_member';

    public function province()
    {
        return $this->belongsTo(Province::class)->withTrashed();
    }

    public function regency()
    {
        return $this->belongsTo(Regency::class)->withTrashed();
    }
}
