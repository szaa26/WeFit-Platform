<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DuitkuCallbackLog extends Model
{
    use HasFactory;
    protected $table = 'duitku_callback_log';
}
