<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Booking extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = 'booking';

    public function venue()
    {
        return $this->belongsTo(Venue::class)->withTrashed();
    }

    public function venue_field()
    {
        return $this->belongsTo(VenueField::class)->withTrashed();
    }

    public function user_member()
    {
        return $this->belongsTo(UserMember::class)->withTrashed();
    }
}
